
import React, { useState, useEffect } from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Upload, Download, Eye, Calendar, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useProfile } from '@/contexts/ProfileContext';
import { Switch } from '@/components/ui/switch';

const AdminCV: React.FC = () => {
  const { toast } = useToast();
  const { profileData, updatePersonalInfo } = useProfile();
  const [fileName, setFileName] = useState(profileData.cvFile || "Ahmed_Jamal_CV.pdf");
  const [lastUpdated, setLastUpdated] = useState(profileData.cvLastUpdated || "May 2, 2025");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [cvSettings, setCvSettings] = useState({
    showDownloadButton: true,
    showUpdateDate: true,
    generateFromProfile: false
  });
  
  useEffect(() => {
    // Update from profile if available
    if (profileData.cvFile) {
      setFileName(profileData.cvFile);
    }
    if (profileData.cvLastUpdated) {
      setLastUpdated(profileData.cvLastUpdated);
    }
  }, [profileData]);
  
  const handleUpload = () => {
    // This would be replaced with actual file upload logic
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.pdf,.doc,.docx';
    
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setFileName(file.name);
        const currentDate = new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'short', 
          day: 'numeric' 
        });
        setLastUpdated(currentDate);
        
        // In a real implementation, we would upload the file to a server
        // and get back a URL that we could use for the CV
        
        toast({
          title: "CV Upload Successful",
          description: `Your CV has been updated to ${file.name}`,
        });
        
        // Update profile context with the CV information
        updatePersonalInfo({
          cvFile: file.name,
          cvLastUpdated: currentDate,
          // This would typically include a URL to the uploaded CV
          cvUrl: URL.createObjectURL(file) // This is temporary and will be revoked when the page refreshes
        });
      }
    };
    
    input.click();
  };
  
  const handleDownload = () => {
    // In a real implementation, this would download the actual CV file
    if (profileData.cvUrl) {
      const link = document.createElement('a');
      link.href = profileData.cvUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      toast({
        title: "Download Started",
        description: "Your CV is being downloaded",
      });
    }
  };
  
  const handlePreview = () => {
    setPreviewOpen(true);
  };

  const handleSettingsChange = (key: string, value: boolean) => {
    setCvSettings(prev => ({
      ...prev,
      [key]: value
    }));

    toast({
      title: "Settings Updated",
      description: `CV setting "${key}" has been ${value ? 'enabled' : 'disabled'}`,
    });

    // In a real implementation, these settings would be saved to the server/database
  };

  const handleGenerateCV = () => {
    toast({
      title: "Generating CV",
      description: "Creating CV from your profile data...",
    });

    // Simulate generating process
    setTimeout(() => {
      const generatedFileName = `${profileData.name.replace(/\s/g, '_')}_Generated_CV.pdf`;
      setFileName(generatedFileName);
      const currentDate = new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
      setLastUpdated(currentDate);

      updatePersonalInfo({
        cvFile: generatedFileName,
        cvLastUpdated: currentDate
      });

      toast({
        title: "CV Generated",
        description: "Your CV has been generated from your profile data",
      });
    }, 2000);
  };
  
  return (
    <AdminLayout title="CV Management">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Current CV</CardTitle>
            <CardDescription>
              Manage and update your curriculum vitae
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-6 border-2 border-dashed rounded-md flex flex-col items-center justify-center text-center">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="font-medium">{fileName}</p>
              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <Calendar className="h-4 w-4" /> Last updated: {lastUpdated}
              </p>
              
              <div className="flex gap-2 mt-4">
                <Button variant="outline" size="sm" onClick={handleDownload}>
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
                <Button variant="outline" size="sm" onClick={handlePreview}>
                  <Eye className="mr-2 h-4 w-4" />
                  Preview
                </Button>
              </div>
            </div>
            
            <Button className="w-full" onClick={handleUpload}>
              <Upload className="mr-2 h-4 w-4" />
              Upload New CV
            </Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>CV Settings</CardTitle>
            <CardDescription>
              Configure how your CV is displayed on the website
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 border rounded-md">
              <span>Show CV download button on public profile</span>
              <Switch 
                checked={cvSettings.showDownloadButton} 
                onCheckedChange={(checked) => handleSettingsChange('showDownloadButton', checked)} 
              />
            </div>
            
            <div className="flex items-center justify-between p-3 border rounded-md">
              <span>Display CV last updated date</span>
              <Switch 
                checked={cvSettings.showUpdateDate}
                onCheckedChange={(checked) => handleSettingsChange('showUpdateDate', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between p-3 border rounded-md">
              <span>Generate CV from profile data</span>
              <Button variant="secondary" size="sm" onClick={handleGenerateCV}>Generate</Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-4xl max-h-screen overflow-auto">
          <DialogHeader>
            <DialogTitle>CV Preview</DialogTitle>
          </DialogHeader>
          {profileData.cvUrl ? (
            <iframe 
              src={profileData.cvUrl} 
              className="w-full aspect-[3/4] border rounded"
              title="CV Preview"
            />
          ) : (
            <div className="aspect-[3/4] bg-muted flex items-center justify-center">
              <p className="text-muted-foreground">CV Preview would appear here</p>
              {/* In a real implementation, this could be an iframe or PDF viewer */}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default AdminCV;
